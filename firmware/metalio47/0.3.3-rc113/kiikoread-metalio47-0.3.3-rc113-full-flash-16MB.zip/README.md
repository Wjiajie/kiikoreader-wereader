# Metalio S31 0.3.3-rc113 — 16 MiB 原始全闪存镜像

镜像大小：16,777,216 字节（16 MiB），目标设备：Metalio 4.7 V1.5 / ESP32-S31。

## 刷写

请先备份设备数据。本镜像包含空白填充区并覆盖整颗 16 MiB 闪存，原有 Wi-Fi/账户设置、书籍缓存、字体等用户数据会被清除。

安装 esptool 5.6.0 后，在镜像所在目录执行（把 COM12 换成实际端口）：

```powershell
python -m esptool --chip esp32s31 --port COM12 --before default-reset --after hard-reset --no-stub write-flash --flash-mode dio --flash-size 16MB --flash-freq 80m 0x0 .\kiikoread-metalio47-0.3.3-rc113-full-flash-16MB.bin
```

不要把本文件当作应用镜像写入 `0x10000`；它是从 `0x0` 写入的整片闪存镜像。仅适用于指定 S31 板型。

## 镜像布局

| 镜像 | 地址 |
|---|---:|
| Bootloader | `0x2000` |
| 分区表 | `0x8000` |
| OTA 初始化数据 | `0xD000` |
| 应用（OTA_0） | `0x10000` |
| 其他区域 | `0xFF` 填充 |

校验 SHA-256：

```powershell
(Get-FileHash .\kiikoread-metalio47-0.3.3-rc113-full-flash-16MB.bin -Algorithm SHA256).Hash.ToLower()
```

结果应与 `SHA256SUMS.txt` 一致。
